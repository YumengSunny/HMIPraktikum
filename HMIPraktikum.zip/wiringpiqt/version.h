#define VERSION "2.50"
#define VERSION_MAJOR 2
#define VERSION_MINOR 50
