#include "basesensor.h"

BaseSensor::BaseSensor()
{
}
